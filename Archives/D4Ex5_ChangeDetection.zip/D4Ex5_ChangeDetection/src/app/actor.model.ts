export class Actor {
  constructor(
    public firstName: string,
    public lastName: string) {}
}